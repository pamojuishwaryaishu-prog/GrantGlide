const STATES = ['Andhra Pradesh','Telangana','Karnataka','Tamil Nadu','Kerala','Maharashtra','Gujarat','West Bengal','Delhi','Uttar Pradesh','Bihar','Rajasthan','Madhya Pradesh','Odisha','Punjab','Other'];
const STAGES = ['Bookmarked', 'Applied', 'Under Review', 'Awarded'];
const DOC_LABELS = { income: 'Income Certificate', caste: 'Caste Certificate', marks: 'Marksheets', bonafide: 'Bonafide Letter', domicile: 'Domicile Certificate', aadhaar: 'Aadhaar Card', bank: 'Bank Passbook' };
const $ = id => document.getElementById(id);
const money = n => '₹' + Number(n).toLocaleString('en-IN');

let app = { docs: {}, tracker: {}, results: [], all: [], filter: 'All' };

const form = $('intake');
STATES.forEach(s => form.state.add(new Option(s)));

// ---------- helpers ----------
const save = () => fetch('/api/state', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ docs: app.docs, tracker: app.tracker }) });
const daysLeft = iso => (new Date(iso) - Date.now()) / 864e5;
function docDaysLeft(d) { return d && d.expiry ? Math.ceil((new Date(d.expiry) - Date.now()) / 864e5) : null; }
function docReady(id) { const d = app.docs[id]; return !!(d && d.ready && !(docDaysLeft(d) !== null && docDaysLeft(d) < 0)); }
function countdown(iso) {
  const ms = new Date(iso) - Date.now();
  if (ms <= 0) return { text: 'Closed', cls: 'grey' };
  const d = Math.floor(ms / 864e5), h = Math.floor(ms / 36e5) % 24, m = Math.floor(ms / 6e4) % 60, s = Math.floor(ms / 1e3) % 60;
  const cls = d < 7 ? 'red' : d < 15 ? 'amber' : '';
  return { text: d > 0 ? `${d}d ${h}h ${m}m ${s}s left` : `${h}h ${m}m ${s}s left`, cls, urgent: d < 7 };
}
function conflictsFor(id) {
  const s = app.all.find(x => x.id === id);
  if (!s || !s.group) return [];
  return Object.keys(app.tracker).filter(k => k !== id && app.all.find(x => x.id === k)?.group === s.group).map(k => app.all.find(x => x.id === k).name);
}

// ---------- matches ----------
async function runMatch(profile) {
  $('error').textContent = '';
  const res = await fetch('/api/match', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(profile) });
  const data = await res.json();
  if (!res.ok) { $('error').textContent = data.error; return; }
  app.results = data.results; app.total = data.total;
  renderPills(); renderCards();
}
function renderPills() {
  const tags = ['All', ...new Set(app.results.flatMap(s => s.tags))];
  $('pills').innerHTML = tags.map(t => `<button class="pill ${t === app.filter ? 'on' : ''}" data-tag="${t}">${t}</button>`).join('');
}
function renderCards() {
  const list = app.results.filter(s => app.filter === 'All' || s.tags.includes(app.filter));
  $('summary').textContent = `${app.results.length} of ${app.total} schemes match your profile.`;
  $('cards').innerHTML = list.map(s => {
    const ready = s.docs.filter(docReady).length;
    const stage = app.tracker[s.id];
    return `<article class="card">
      <h3>${s.name}</h3><div class="body">${s.body}</div>
      <div class="row"><span class="amount">${money(s.amount)}<small>/yr</small></span><span class="badge cd" data-deadline="${s.deadline}"></span></div>
      <div class="bar"><i style="width:${s.match.score}%"></i></div>
      <div class="row muted"><span>Match ${s.match.score}%</span><span>Docs ${ready}/${s.docs.length} ready</span></div>
      <div>${s.tags.map(t => `<span class="badge grey">${t}</span> `).join('')}</div>
      ${conflictsFor(s.id).length ? '<div class="notice bad">Conflict with another saved scheme</div>' : ''}
      <div class="actions"><button data-open="${s.id}">Details</button><button data-mark="${s.id}">${stage ? '✓ ' + stage : 'Bookmark'}</button></div>
    </article>`;
  }).join('') || '<p class="muted">No schemes in this category.</p>';
  tick();
}
function tick() {
  document.querySelectorAll('.cd').forEach(el => {
    const c = countdown(el.dataset.deadline);
    el.textContent = c.text; el.className = 'badge cd ' + c.cls;
  });
}
setInterval(tick, 1000);

// ---------- details + checklist ----------
function openModal(id) {
  const s = app.all.find(x => x.id === id);
  const conflicts = conflictsFor(id);
  $('modalBody').innerHTML = `<button class="close" data-close>×</button>
    <h2>${s.name}</h2><p class="muted">${s.body}</p>
    <div class="row"><span class="amount">${money(s.amount)} / year</span><span class="badge cd" data-deadline="${s.deadline}"></span></div>
    <p><b>Renewal:</b> ${s.renewal}</p>
    <p><a href="${s.portal}" target="_blank" rel="noopener">Official portal ↗</a> <span class="muted">(confirm dates and rules there before applying)</span></p>
    ${conflicts.length ? `<div class="notice bad">Policy conflict: you've saved ${conflicts.join(', ')}. Schemes in this group usually do not allow dual availing.</div>` : ''}
    <h3>Document checklist (${s.docs.filter(docReady).length}/${s.docs.length} ready)</h3>
    ${s.docs.map(d => docRow(d)).join('')}
    <div class="row"><label>Application stage
      <select data-stage="${s.id}"><option value="">Not saved</option>${STAGES.map(x => `<option ${app.tracker[s.id] === x ? 'selected' : ''}>${x}</option>`).join('')}</select></label></div>`;
  $('modal').showModal(); tick();
}
function docRow(id) {
  const d = app.docs[id] || { ready: false, expiry: '' };
  const left = docDaysLeft(d);
  const expiring = d.ready && left !== null && left <= 30;
  const note = expiring ? (left < 0 ? 'Expired – renew now' : `${DOC_LABELS[id]} needs renewal (${left} days left)`) : '';
  return `<div class="doc ${expiring ? 'expiring' : ''}"><label style="flex-direction:row;gap:8px;color:inherit"><input type="checkbox" data-doc="${id}" ${d.ready ? 'checked' : ''}>
    <span>${DOC_LABELS[id]}${note ? `<small>${note}</small>` : ''}</span></label>
    <input type="date" data-expiry="${id}" value="${d.expiry || ''}" title="Expiry date (optional)"></div>`;
}
function renderAlerts() {
  const soon = Object.entries(app.docs).filter(([, d]) => d.ready && docDaysLeft(d) !== null && docDaysLeft(d) <= 30);
  $('alerts').innerHTML = soon.length ? `<div class="notice">⚠ Expiring soon: ${soon.map(([id, d]) => `${DOC_LABELS[id]} (${docDaysLeft(d)}d)`).join(', ')}. Ask your local revenue office (MeeSeva / tahsildar) for a fresh copy.</div>` : '';
}

// ---------- pipeline ----------
function renderBoard() {
  $('board').innerHTML = STAGES.map(st => {
    const items = Object.entries(app.tracker).filter(([, v]) => v === st).map(([id]) => app.all.find(s => s.id === id)).filter(Boolean);
    return `<div class="col"><h4>${st} (${items.length})</h4>${items.map(s => `<div class="mini" data-open="${s.id}"><b>${s.name}</b><br><span class="badge cd" data-deadline="${s.deadline}"></span></div>`).join('') || '<span class="muted">Empty</span>'}</div>`;
  }).join('');
  tick();
}
function refresh() { renderAlerts(); renderCards(); renderBoard(); }

// ---------- events ----------
document.addEventListener('click', e => {
  const t = e.target;
  if (t.dataset.tag) { app.filter = t.dataset.tag; renderPills(); renderCards(); }
  if (t.dataset.open || t.closest('[data-open]')) openModal(t.dataset.open || t.closest('[data-open]').dataset.open);
  if (t.dataset.mark) { if (app.tracker[t.dataset.mark]) delete app.tracker[t.dataset.mark]; else app.tracker[t.dataset.mark] = 'Bookmarked'; save(); refresh(); }
  if (t.dataset.close !== undefined) $('modal').close();
  if (t.classList.contains('tab')) {
    document.querySelectorAll('.tab').forEach(b => b.classList.toggle('on', b === t));
    $('matches').hidden = t.dataset.tab !== 'matches'; $('pipeline').hidden = t.dataset.tab !== 'pipeline';
  }
});
document.addEventListener('change', e => {
  const t = e.target;
  if (t.dataset.doc) { app.docs[t.dataset.doc] = { ...(app.docs[t.dataset.doc] || {}), ready: t.checked }; }
  else if (t.dataset.expiry) { app.docs[t.dataset.expiry] = { ...(app.docs[t.dataset.expiry] || { ready: false }), expiry: t.value }; }
  else if (t.dataset.stage) { t.value ? app.tracker[t.dataset.stage] = t.value : delete app.tracker[t.dataset.stage]; }
  else return;
  save(); refresh();
  const open = document.querySelector('#modalBody h2');
  if (open && (t.dataset.doc || t.dataset.expiry || t.dataset.stage)) { const s = app.all.find(x => x.name === open.textContent); if (s) openModal(s.id); }
});
form.addEventListener('submit', e => { e.preventDefault(); runMatch(Object.fromEntries(new FormData(form))); });
$('demo').addEventListener('click', () => {
  Object.entries({ caste: 'BC', income: 150000, state: 'Telangana', gender: 'Female', degree: 'Engineering', gpa: 8.5 }).forEach(([k, v]) => form[k].value = v);
  runMatch(Object.fromEntries(new FormData(form)));
});

// ---------- start ----------
(async function init() {
  app.all = await (await fetch('/api/scholarships')).json();
  const st = await (await fetch('/api/state')).json();
  app.docs = st.docs || {}; app.tracker = st.tracker || {};
  if (st.profile) { Object.entries(st.profile).forEach(([k, v]) => form[k] && (form[k].value = v)); await runMatch(st.profile); }
  refresh();
})();
