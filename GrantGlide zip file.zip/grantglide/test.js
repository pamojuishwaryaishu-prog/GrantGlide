const fs = require('fs');
const { matchAll } = require('./matcher');
const list = JSON.parse(fs.readFileSync('./data/scholarships.json', 'utf8'));
const cases = [
  { name: 'Demo: Telangana BC girl, engineering', p: { caste: 'BC', income: 150000, state: 'Telangana', gender: 'Female', degree: 'Engineering', gpa: 8.5 }, mustHave: ['pragati', 'ts-bc', 'post-matric-obc'], mustNot: ['ts-scst', 'top-class-sc'] },
  { name: 'SC boy, Telangana, 1.8L', p: { caste: 'SC', income: 180000, state: 'Telangana', gender: 'Male', degree: 'Engineering', gpa: 6.2 }, mustHave: ['post-matric-sc', 'ts-scst', 'top-class-sc'], mustNot: ['pragati'] },
  { name: 'General, high income', p: { caste: 'General', income: 3000000, state: 'Telangana', gender: 'Male', degree: 'Arts', gpa: 9 }, mustHave: [], mustNot: ['post-matric-sc', 'csss'] }
];
let bad = 0;
for (const c of cases) {
  const ids = matchAll(list, c.p).map(s => s.id);
  const errs = [...c.mustHave.filter(x => !ids.includes(x)), ...c.mustNot.filter(x => ids.includes(x))];
  console.log(errs.length ? 'FAIL' : 'ok  ', c.name, '->', ids.length, 'matches', errs.join(','));
  bad += errs.length;
}
process.exit(bad ? 1 : 0);
