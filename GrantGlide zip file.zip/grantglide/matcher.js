// Rule engine. A scholarship has `rules`: a list of alternatives (OR).
// Each alternative is a set of conditions that must ALL pass (AND).
function checkRule(rule, p) {
  const fails = [];
  let checked = 0;
  const test = (key, ok, label) => { if (rule[key] === undefined) return; checked++; if (!ok) fails.push(label); };
  test('castes', rule.castes && rule.castes.includes(p.caste), 'caste category');
  test('maxIncome', p.income <= rule.maxIncome, 'family income');
  test('minGpa', p.gpa >= rule.minGpa, 'GPA');
  test('genders', rule.genders && rule.genders.includes(p.gender), 'gender');
  test('states', rule.states && rule.states.includes(p.state), 'domicile state');
  test('degrees', rule.degrees && rule.degrees.includes(p.degree), 'degree');
  return { fails, checked };
}

function evaluate(s, p) {
  let best = null;
  for (const alt of s.rules) {
    const r = checkRule(alt, p);
    if (!best || r.fails.length < best.fails.length) best = r;
  }
  const eligible = best.fails.length === 0;
  // More specific schemes that you still pass are a stronger fit.
  const score = eligible ? Math.min(100, 55 + best.checked * 9) : 0;
  return { eligible, score, fails: best.fails };
}

function matchAll(list, p) {
  return list.map(s => ({ ...s, match: evaluate(s, p) }))
    .filter(s => s.match.eligible)
    .sort((a, b) => b.match.score - a.match.score || new Date(a.deadline) - new Date(b.deadline));
}
module.exports = { evaluate, matchAll };
