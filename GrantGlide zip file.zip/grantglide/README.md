# GrantGlide – ScholarQuest

Scholarship matching web app: intake form, rule-based eligibility engine, live deadline countdowns,
document readiness checklist with expiry alerts, and an application pipeline.

## Run
```
npm install
npm start        # http://localhost:3000
npm test         # checks the matching engine on sample profiles
```

## How it works
- `matcher.js` – each scheme has `rules`, a list of alternatives (OR). Inside one alternative every condition must pass (AND): caste, max income, min GPA, gender, state, degree. A missing condition means "any".
- `server.js` – Express REST API: `/api/match`, `/api/scholarships`, `/api/state` (profile, document status and tracker saved to `data/store.json`).
- `data/scholarships.json` – 30 schemes. **Amounts, deadlines and income limits are approximate placeholders; verify on each official portal before relying on them.**
- `public/` – vanilla JS frontend (countdowns, filter pills, checklist, pipeline, conflict badge via the `group` field).

## Ideas to extend
Financial aid calculator, WhatsApp alert simulator, multilingual summaries, nested AND/OR predicate trees.
