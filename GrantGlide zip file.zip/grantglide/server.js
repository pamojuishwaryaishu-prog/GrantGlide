const express = require('express');
const fs = require('fs');
const path = require('path');
const { matchAll } = require('./matcher');

const app = express();
const STORE = path.join(__dirname, 'data', 'store.json');
const scholarships = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'scholarships.json'), 'utf8'));

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const daysFromNow = n => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);
function defaultState() {
  return { profile: null, tracker: {},
    docs: { income: { ready: true, expiry: daysFromNow(20) }, marks: { ready: true, expiry: '' }, aadhaar: { ready: true, expiry: '' } } };
}
function readState() {
  try { return JSON.parse(fs.readFileSync(STORE, 'utf8')); } catch { return defaultState(); }
}

app.get('/api/scholarships', (req, res) => res.json(scholarships));
app.get('/api/scholarships/:id', (req, res) => {
  const s = scholarships.find(x => x.id === req.params.id);
  s ? res.json(s) : res.status(404).json({ error: 'Not found' });
});
app.post('/api/match', (req, res) => {
  const p = req.body || {};
  p.income = Number(p.income); p.gpa = Number(p.gpa);
  if (!p.caste || !p.state || !p.gender || !p.degree || isNaN(p.income) || isNaN(p.gpa))
    return res.status(400).json({ error: 'Please fill every field.' });
  const state = readState();
  state.profile = p;
  fs.writeFileSync(STORE, JSON.stringify(state, null, 2));
  res.json({ total: scholarships.length, results: matchAll(scholarships, p) });
});
app.get('/api/state', (req, res) => res.json(readState()));
app.put('/api/state', (req, res) => {
  const { docs, tracker } = req.body;
  const state = readState();
  if (docs) state.docs = docs;
  if (tracker) state.tracker = tracker;
  fs.writeFileSync(STORE, JSON.stringify(state, null, 2));
  res.json({ ok: true });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`GrantGlide running at http://localhost:${PORT}`));
